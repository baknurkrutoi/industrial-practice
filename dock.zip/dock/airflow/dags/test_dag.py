from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import logging

def hello_airflow():
    logging.info("🎉 Airflow работает!")

default_args = {
    'start_date': datetime(2023, 1, 1),
}

with DAG(
    dag_id='test_dag',
    default_args=default_args,
    schedule=None,  # <-- Новое имя параметра
    catchup=False,
    tags=["test"],
) as dag:

    task_hello = PythonOperator(
        task_id='say_hello',
        python_callable=hello_airflow,
    )
