import pandas as pd
from sdv.single_table import CTGANSynthesizer
from sdv.metadata import SingleTableMetadata

def generate_dummy_data(input_csv, output_csv, n_rows=9900):
    print(f"▶️ Обработка файла: {input_csv}")

    # Шаг 1: Загрузка CSV
    df = pd.read_csv(input_csv, sep=';', encoding='utf-8')

    # Шаг 2: Заполнение пропущенных значений
    for col in df.columns:
        if df[col].dtype in ['float64', 'int64']:
            df[col] = df[col].fillna(df[col].mean())
        else:
            df[col] = df[col].fillna('missing')

    print(f"📉 После заполнения NaN осталось строк: {len(df)}")

    # Шаг 3: Определение метаданных
    metadata = SingleTableMetadata()
    metadata.detect_from_dataframe(data=df)

    print("📊 Обнаруженные типы колонок:")
    for col, props in metadata.to_dict()['columns'].items():
        print(f"  {col}: {props['sdtype']}")

    # Шаг 4: Обучение модели
    model = CTGANSynthesizer(metadata=metadata, epochs=300)
    model.fit(df)

    # Шаг 5: Генерация синтетических данных
    synthetic = model.sample(n_rows)

    # Шаг 6: Сохранение
    synthetic.to_csv(output_csv, sep=';', index=False, encoding='utf-8')
    print(f"✅ Синтетические данные сохранены в '{output_csv}'\n")

# Генерация dummy-данных для e_obr.csv
generate_dummy_data("e_obr.csv", "e_obr_synthetic.csv", n_rows=9900)

# Генерация dummy-данных для kezekte.csv
generate_dummy_data("kezekte.csv", "kezekte_synthetic.csv", n_rows=9900)
