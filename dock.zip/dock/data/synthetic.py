import pandas as pd
from sdv.single_table import CTGANSynthesizer
from sdv.metadata import SingleTableMetadata

# Шаг 1: Загрузка CSV
df = pd.read_csv("CKS.csv", sep=';', encoding='utf-8')

# Шаг 2: Создание метаданных таблицы
metadata = SingleTableMetadata()
metadata.detect_from_dataframe(data=df)

# (Необязательно) Показать, как SDV определил типы
print("📊 Обнаруженные типы колонок:")
for col, props in metadata.to_dict()['columns'].items():
    print(f"  {col}: {props['sdtype']}")

# Шаг 3: Инициализация и обучение модели
model = CTGANSynthesizer(metadata=metadata, epochs=300)
model.fit(df)

# Шаг 4: Генерация 10,000 строк
synthetic = model.sample(8000)

# Шаг 5: Сохранение в CSV
synthetic.to_csv("CKS_synthetic.csv", sep=';', index=False, encoding='utf-8')
print("✅ Готово! Данные сохранены в 'CKS_synthetic.csv'")
